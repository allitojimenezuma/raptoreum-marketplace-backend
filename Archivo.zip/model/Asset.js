import { DataTypes } from 'sequelize';
import sequelize from '../db.js';

const Asset = sequelize.define('Asset', {
  asset_id: {
    type: DataTypes.STRING
  },
  nombre: {
    type: DataTypes.STRING,
    allowNull: false
  },
  precio: {
    type: DataTypes.INTEGER,
    nullable: false
  }
});

export default Asset;
