import { sequelize, Usuario, Wallet } from './model/index.js';

async function getUsuario() {
  try {
    await sequelize.authenticate();
    console.log('✅ Conexión establecida');

    //obtener usuario por id
    const usuarioId = 3; // Cambia esto al ID del usuario que deseas obtener
    const usuario = await Usuario.findByPk(usuarioId);
    if (!usuario) {
      console.log('❌ Usuario no encontrado');
      return;
    }
    console.log('✅ Usuario encontrado:', usuario.toJSON());

    //Obtener wallets del usuario
    const wallets = await usuario.getWallets();
    if (wallets.length === 0) {
      console.log('❌ No se encontraron wallets para este usuario');
      return;
    }
    console.log('✅ Wallets encontradas:', wallets.map(wallet => wallet.toJSON()));

  } catch (error) {
    console.error('❌ Error al crear usuario o wallet:', error);
  } finally {
    await sequelize.close();
  }
}

getUsuario();
